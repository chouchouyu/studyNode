<template>
    <div>
      <button>+</button>
      <button>-</button>
    </div>
</template>
<script>
    export default {
        data(){
            return {}
        },
        computed: {},
        components: {},
        methods: {}
    }
</script>
<style scoped>

</style>
